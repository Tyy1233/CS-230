module GamingRoom {
}